# PROJECT  : BANK PROCESS AUTOMATION USING RPA.
# DESCRIPTION : Bank Automation RPA Project using Speech Recognition

 * Automating the bank employers process.
 * Personal details are gathered through the Chat Bot.
 * Identifying whether the customer is existing or not.Based on that further steps are carried out.
 * If new,Obtain the purpose to visit.Based on the purpose further steps are carried out. 
 * If customer is existing,then obtain details for the service.
 * The mentioned service will be redirected to the specific Bank Employee.
 * For Loan Section following properties are verified previous transactions,credit points and based on the property value the loan is sanctioned.
 * Focusing on both the Customer and Employers satisfaction.
